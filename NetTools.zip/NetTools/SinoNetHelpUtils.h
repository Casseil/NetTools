//
//  SinoNetHelpUtils.h
//  PremiumService
//
//  Created by ZKR on 16/9/24.
//  Copyright © 2016年 ZKR. All rights reserved.
//

#import <Foundation/Foundation.h>


// 还未自定义错误原因
typedef NS_ENUM(NSInteger, V2ErrorType) {
    
    V2ErrorTypeNoOnceAndNext          = 700,
    V2ErrorTypeLoginFailure           = 701,
    V2ErrorTypeRequestFailure         = 702,
    V2ErrorTypeGetFeedURLFailure      = 703,
    V2ErrorTypeGetTopicListFailure    = 704,
    V2ErrorTypeGetNotificationFailure = 705,
    V2ErrorTypeGetFavUrlFailure       = 706,
    V2ErrorTypeGetMemberReplyFailure  = 707,
    V2ErrorTypeGetTopicTokenFailure   = 708,
    V2ErrorTypeGetCheckInURLFailure   = 709,
    
};


@interface SinoNetHelpUtils : NSObject

+ (instancetype)manager;// 网络请求单例



#pragma mark - 以上为可重用部分

#pragma mark - 网络请求的方法
- (NSURLSessionDataTask *)getLocatonList1WithUrl:(NSString *)url
                                         success:(void (^)(id returnData))success
                                         failure:(void (^)(NSError *error))failure ;



- (NSURLSessionDataTask *)post:(NSString *)url para:(NSDictionary*)para
                       success:(void (^)(id returnData))success
                       failure:(void (^)(NSError *error))failure;


// 上传图片

-(void)uploadPicture:(NSString*)url data:(NSData *)data  fileName:(NSString*)fileName localUrlPath:(NSString *)localUrlPath parameters:(NSDictionary *)parameters  progress:(void (^)(float progress))uploadProgress  success:(void (^)(id returnData))success failure:(void (^)(NSError *))uploadFailure;

-(void)uploadFilePicture:(NSString*)url data:(NSData *)data  fileName:(NSString*)fileName localUrlPath:(NSString *)localUrlPath parameters:(NSDictionary *)parameters  progress:(void (^)(float progress))uploadProgress  success:(void (^)(id))uploadSuccess failure:(void (^)(NSError *))uploadFailure;



- (NSURLSessionDataTask *)upPicToYunmai:(NSString *)url para:(NSDictionary*)para
                                success:(void (^)(id returnData))success
                                failure:(void (^)(NSError *error))failure;
-(void)cancelAll;



// 字符串转为字典
+(NSDictionary *)parseJSONStringToNSDictionary:(NSString *)JSONString ;

//数组转为字符串
+(NSString*)parseArrayToStr:(id)arr;
@end
