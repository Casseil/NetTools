//
//  SinoNetHelpUtils.m
//  PremiumService
//
//  Created by ZKR on 16/9/24.
//  Copyright © 2016年 ZKR. All rights reserved.
//

#import "SinoNetHelpUtils.h"
#import "AFNetworking.h"
// 网络请求的方式
typedef NS_ENUM(NSInteger, SinoRequestMethod) {
    SinoRequestMethodJSONGET    = 1,
    SinoRequestMethodHTTPPOST   = 2,
    SinoRequestMethodHTTPGET    = 3,
    SinoRequestMethodHTTPGETPC  = 4
};


@interface SinoNetHelpUtils()

@property (nonatomic, strong) AFHTTPSessionManager *manager;

@end
@implementation SinoNetHelpUtils
#pragma mark - base method

+ (instancetype)manager {
    static SinoNetHelpUtils *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[SinoNetHelpUtils alloc] init];
    });
    return manager;
}




- (NSURLSessionDataTask *)requestWithMethod:(SinoRequestMethod)method
                                  URLString:(NSString *)URLString
                                 parameters:(NSDictionary *)parameters
                                    success:(void (^)(NSURLSessionDataTask *task, id responseObject))success
                                    failure:(void (^)(NSError *error))failure  {
    if (_manager ==nil) {
        self.manager = [[AFHTTPSessionManager alloc] init ];
    }
    // stateBar
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];//显示网络请求的旋转齿轮
    
    // Handle Common Mission, Cache, Data Reading & etc.
    void (^responseHandleBlock)(NSURLSessionDataTask *task, id responseObject) = ^(NSURLSessionDataTask *task, id responseObject) {
        
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        //        NSLog(@"URL:\n%@", [task.currentRequest URL].absoluteString);
        success(task, responseObject);
        
    };
    
    // Create HTTPSession
    NSURLSessionDataTask *task = nil;
    
    // [self.manager.requestSerializer setValue:self.userAgentMobile forHTTPHeaderField:@"User-Agent"];
    
    if (method == SinoRequestMethodJSONGET) {
        AFHTTPResponseSerializer *responseSerializer = [AFJSONResponseSerializer serializer];
        self.manager.responseSerializer = responseSerializer;
        self.manager.requestSerializer=[AFJSONRequestSerializer serializer];//申明请求的数据是json类型
        
        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/html",@"text/json",@"text/javascript",@"application/x-www-form-urlencoded",@"application/xhtml+xml",@"application/xml", nil ];
        
        [self.manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        
        self.manager.requestSerializer.timeoutInterval = 180;
        
        
        task = [self.manager GET:URLString parameters:parameters success:^(NSURLSessionDataTask *task, id responseObject) {
            responseHandleBlock(task, responseObject);
            
            
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            // SinoLog(@"Error: \n%@", [error description]);
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            failure(error);
        }];
    }
    
    
    
    
    if (method == SinoRequestMethodHTTPGET) {
        AFHTTPResponseSerializer *responseSerializer = [AFHTTPResponseSerializer serializer];
        self.manager.responseSerializer = responseSerializer;
        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/html",@"text/json",@"text/javascript",@"application/x-www-form-urlencoded",@"application/xhtml+xml",@"application/xml", nil ];
        
        [self.manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        
        task = [self.manager GET:URLString parameters:parameters success:^(NSURLSessionDataTask *task, id responseObject) {
            responseHandleBlock(task, responseObject);
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            failure(error);
        }];
    }
    if (method == SinoRequestMethodHTTPPOST) {
        AFHTTPResponseSerializer *responseSerializer = [AFHTTPResponseSerializer serializer];
        self.manager.responseSerializer = responseSerializer;
        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/html",@"text/json",@"text/javascript",@"application/x-www-form-urlencoded",@"application/xhtml+xml",@"application/xml", nil ];
        
        [self.manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        task = [self.manager POST:URLString parameters:parameters success:^(NSURLSessionDataTask *task, id responseObject) {
            responseHandleBlock(task, responseObject);
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            failure(error);
        }];
    }
    if (method == SinoRequestMethodHTTPGETPC) {
        AFHTTPResponseSerializer *responseSerializer = [AFHTTPResponseSerializer serializer];
        self.manager.responseSerializer = responseSerializer;
        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/html",@"text/json",@"text/javascript", nil ];
        //  [self.manager.requestSerializer setValue:self.userAgentPC forHTTPHeaderField:@"User-Agent"];
        task = [self.manager GET:URLString parameters:parameters success:^(NSURLSessionDataTask *task, id responseObject) {
            responseHandleBlock(task, responseObject);
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            failure(error);
        }];
    }
    
    return task;
}

#pragma mark - 以上为可重用部分


#pragma mark - 网络请求的方法
- (NSURLSessionDataTask *)getLocatonList1WithUrl:(NSString *)url
                                         success:(void (^)(id returnData))success
                                         failure:(void (^)(NSError *error))failure {
    
    return [self requestWithMethod:SinoRequestMethodJSONGET URLString:url parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        //V2NodeList *list = [[V2NodeList alloc] initWithArray:responseObject];
        NSArray* arr = responseObject;
        
        success(arr);
    } failure:^(NSError *error) {
        failure(error);
    }];
}


- (NSURLSessionDataTask *)getWality:(NSString *)url
                            success:(void (^)(id returnData))success
                            failure:(void (^)(NSError *error))failure {
    return [self requestWithMethod:SinoRequestMethodJSONGET URLString:url parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        success(responseObject);
        
        
    } failure:^(NSError *error) {
        failure(error);
    }];
}


+(NSDictionary *)parseJSONStringToNSDictionary:(NSString *)JSONString {
    NSData *JSONData = [JSONString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *responseJSON = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingMutableLeaves error:nil];
    return responseJSON;
}

+(NSString*)parseArrayToStr:(id)arr{
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization
                        dataWithJSONObject:arr options:kNilOptions error:&error];
    NSString* str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return str;
}


//获取
- (NSURLSessionDataTask *)post:(NSString *)url para:(NSDictionary*)para
                           success:(void (^)(id returnData))success
                           failure:(void (^)(NSError *error))failure {
    return [self requestWithMethod:SinoRequestMethodHTTPPOST URLString:url parameters:para success:^(NSURLSessionDataTask *task, id responseObject) {
        success(responseObject);
        
        
    } failure:^(NSError *error) {
        failure(error);
    }];
}
// 上传图片

-(void)uploadPicture:(NSString*)url data:(NSData *)data  fileName:(NSString*)fileName localUrlPath:(NSString *)localUrlPath parameters:(NSDictionary *)parameters  progress:(void (^)(float progress))uploadProgress  success:(void (^)(id returnData))success failure:(void (^)(NSError *))uploadFailure{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects :@"text/html",@"application/x-www-form-urlencoded",@"application/json",@"multipart/form-data",nil];
    [manager.requestSerializer setValue:@"multipart/form-data" forHTTPHeaderField:@"Content-Type"];
    
    
    NSURLSessionDataTask *uploadTask= [manager POST:url parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if (data !=nil) {
            [formData appendPartWithFileData:data name:@"commentImgs" fileName:fileName mimeType:@"image/jpeg"];
            if (parameters[@"shopOrderId"]) {
                [formData appendPartWithFileData:data name:@"shoporderImgs" fileName:fileName mimeType:@"image/jpeg"];
                
            }
        }

    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
         success(responseObject);
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         uploadFailure(error);
    }];
    
    
    
    /*
    AFHTTPRequestOperation* fileUploadOp =  [manager POST:url  parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        
        if (data !=nil) {
            [formData appendPartWithFileData:data name:@"commentImgs" fileName:fileName mimeType:@"image/jpeg"];
            if (parameters[@"shopOrderId"]) {
                [formData appendPartWithFileData:data name:@"shoporderImgs" fileName:fileName mimeType:@"image/jpeg"];
                
            }
        }
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        uploadSuccess(responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        uploadFailure(error);
    }];
    
    
    
    [NSURLSessionDataTask setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
        CGFloat progress = ((float)totalBytesWritten) / totalBytesExpectedToWrite;
        NSLog(@"进度%f",progress);
        uploadProgress(progress);
    }];
    
    */
    
    
    
}



@end
